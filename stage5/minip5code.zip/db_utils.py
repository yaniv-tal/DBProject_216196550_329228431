import psycopg2

def connect():
    return psycopg2.connect(
        dbname="mydatabase",
        user="ahuvyab",
        password="12345qwert",
        host="localhost",
        port="5432"
    )
